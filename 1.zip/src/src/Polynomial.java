package src;

import java.util.Scanner;
import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.LinkedList;

public class Polynomial {
    private static LinkedList<BigDecimal> indexList = new LinkedList<>();
    private static LinkedList<BigDecimal> expList = new LinkedList<>();

    private static void initNew(String line0) {
        String line = line0;
        Pattern pattern = Pattern.compile("^([+-])([+-])?(\\d+\\*)?(x)" +
                "(\\^[+-]?\\d+)?|^([+-])([+-]?\\d+)");
        Matcher match = pattern.matcher(line);
        while (match.find()) {
            BigDecimal op = new BigDecimal("1");
            if (match.group(1) == null) {
                if (match.group().split("")[0].equals("-")) {
                    op = op.negate();
                } expList.add(new BigDecimal(0));
                Pattern number = Pattern.compile("([+-])([+-]?\\d+)");
                Matcher num = number.matcher(match.group());
                if (num.matches()) {
                    indexList.add(new BigDecimal(num.group(2)).multiply(op));
                }
            } else {
                if (match.group(1).equals("-")) {
                    op = op.negate();
                } if (match.group().length() >= 2 && match.group(2) != null) {
                    if (match.group(2).equals("-")) {
                        op = op.negate();
                    }
                } if (match.group(3) != null) {
                    String temp = match.group(3).split("\\*")[0];
                    try {
                        indexList.add(new BigDecimal(temp).multiply(op));
                    } catch (Exception e) {
                        System.out.print("WRONG FORMAT!");
                        System.exit(0);
                    }
                } else {
                    indexList.add(new BigDecimal("1").multiply(op));
                }
                Pattern markEff = Pattern.compile("\\^[+-]?\\d+");
                Matcher searchEff = markEff.matcher(match.group());
                if (!searchEff.find()) {
                    expList.add(new BigDecimal(1));
                } else {
                    String[] list = searchEff.group().split("\\^");
                    String temp = list[list.length - 1];
                    try {
                        expList.add(new BigDecimal(temp));
                    } catch (Exception e) {
                        System.out.print("WRONG FORMAT!");
                        System.exit(0);
                    }
                }
            }
            line = match.replaceFirst("");
            match = pattern.matcher(line);
        }
        if (line.length() != 0) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        }
    }

    private static void me(BigDecimal[] exp, BigDecimal[] index, int[] mark) {
        for (int i = 1; i < exp.length; i++) {
            for (int k = 0; k < i; k++) {
                if (exp[i].compareTo(exp[k]) == 0 && mark[k] == 0) {
                    index[k] = index[k].add(index[i]);
                    mark[i] = 1;
                }
            }
        }
    }

    private static void derive(BigDecimal[][] poly, Poly[] element) {
        for (int i = 0; i < poly[0].length; i++) {
            element[i] = new Poly(poly[1][i], poly[0][i]);
            element[i] = element[i].calculate();
        }
        int flagNew = 1;
        for (Poly i : element) {
            if (i.index().compareTo(new BigDecimal(0)) != 0) {
                flagNew = 0;
                break;
            }
        }
        if (flagNew != 0) {
            System.out.print(0);
            System.exit(0);
        }
        if (element.length == 1) {
            if (element[0].exp().compareTo(new BigDecimal(0)) == 0)
            {
                System.out.print(element[0].index());
                System.exit(0);
            }
        } for (int i = 0; i < element.length; i++) {
            if (element[i].index().compareTo(new BigDecimal(0)) != 0) {
                if (element[i].index().compareTo(new BigDecimal(0)) > 0) {
                    int flag = 0;
                    for (int j = 0; j < i; j++) {
                        BigDecimal temp = new BigDecimal(0);
                        if (element[j].index().compareTo(temp) != 0)
                        {
                            flag = 1;
                        }
                    }
                    if (flag != 0) {
                        System.out.print("+");
                    }
                }
                System.out.print(element[i].index());
                if (element[i].exp().compareTo(new BigDecimal(0)) != 0) {
                    System.out.print("*x");
                    if (element[i].exp().compareTo(new BigDecimal(1)) != 0) {
                        System.out.print("^");
                        System.out.print(element[i].exp());
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line0 = sc.nextLine();
        if (line0.length() == 0 || line0.split("\\s*").length == 0) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        }
        Pattern initJudge = Pattern.compile("^\\s*([+-]?[0-9]*\\s*)?\\s*" +
                "(\\*)?x\\s*((\\^)(\\s*)([+-]?[0-9]+))?|^\\s*([+-]?\\d+)");
        Matcher start = initJudge.matcher(line0);
        if (start.find()) {
            line0 = "+" + line0;
        }
        Pattern wrong = Pattern.compile("[+-]+\\s*[+-]\\s+\\d+|" +
                "\\d+\\s+\\d+|\\d+\\s*x|x\\s*\\d+|[\\f\\n\\r\\v]+" +
                "|\\^\\s*[+-]\\s+\\d+");
        Matcher wrongSpace = wrong.matcher(line0);
        if (wrongSpace.find()) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        }
        line0 = line0.replaceAll("\\s*","");
        initNew(line0);
        int[] mark = new int[indexList.size()];
        BigDecimal[] exp = expList.toArray(new BigDecimal[0]);
        BigDecimal[] ind = indexList.toArray(new BigDecimal[0]);
        me(exp,ind,mark);
        int count = 0;
        for (int element:mark) {
            if (element == 0) {
                count++;
            }
        }
        BigDecimal[][] poly = new BigDecimal[2][count];
        int top = 0;
        for (int i = 0;i < indexList.size();i++) {
            if (mark[i] == 0) {
                poly[0][top] = exp[i];
                poly[1][top++] = ind[i];
            }
        }
        Poly[] element = new Poly[count];
        derive(poly,element);
    }
}

