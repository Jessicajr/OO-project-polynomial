package src;

import java.math.BigDecimal;

class Poly {
    private BigDecimal in;
    private BigDecimal ex;

    public Poly(BigDecimal n,BigDecimal m) {
        this.in = n;
        this.ex = m;
    }

    public Poly calculate() {
        BigDecimal tempExp;
        BigDecimal tempIndex = this.in.multiply(this.ex);
        if (this.ex.compareTo(new BigDecimal(0)) != 0) {
            tempExp = this.ex.subtract(new BigDecimal(1));
        } else {
            tempExp = new BigDecimal(0);
        }
        Poly result = new Poly(tempIndex,tempExp);
        return result;
    }

    public BigDecimal index() {
        return this.in;
    }

    public BigDecimal exp() {
        return this.ex;
    }

}
