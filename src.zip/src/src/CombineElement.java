package src;

interface CombineElement {
    public void getChild();
}