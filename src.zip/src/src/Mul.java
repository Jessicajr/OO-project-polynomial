package src;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Mul extends Combine implements CombineElement {
    private Combine right;

    public Mul(String str,int mark) {
        super(str,mark);
    }

    public Combine getRi() {
        return this.right;
    }

    @Override
    public void getChild() {
        int flag = 0;
        int i;
        int j;
        char[] rawOp = this.getEx().toCharArray();
        StringBuilder left = new StringBuilder();
        for (i = 0; i < rawOp.length; i++) {
            if (rawOp[i] != '*') {
                left.append(rawOp[i]);
                if (rawOp[i] == '(') {
                    flag++;
                }
                if (rawOp[i] == ')') {
                    flag--;
                }
            } else if (flag == 0) {
                this.setLe(new Combine(left.toString(),0));
                break;
            } else {
                left.append(rawOp[i]);
            }
        }
        StringBuilder right = new StringBuilder();
        for (j = i + 1;j < rawOp.length;j++) {
            right.append(rawOp[j]);
        }
        this.right = new Combine(right.toString(),0);
    }

    @Override
    public String getDiff(String strLeft,String strRight) {
        Pattern zeroMatch = Pattern.compile("^0$|^\\(0\\)$");
        Matcher match1 = zeroMatch.matcher(strLeft);
        Matcher match2 = zeroMatch.matcher(strRight);
        String str = new String();
        if (match1.matches() && match2.matches()) {
            str = "0";
        } else if (match1.matches()) {
            str = "+(" + strRight + ")*(" + this.getLe().getEx() + ")";
        } else if (match2.matches()) {
            str = "(" + strLeft + ")*(" + this.right.getEx() + ")";
        } else {
            str = "(" + strLeft + ")*(" + this.right.getEx() + ")";
            str += "+(" + strRight + ")*(" + this.getLe().getEx() + ")";
        }
        return str;
    }

    @Override
    public boolean legal() {
        return (valid(this.getLe()) && valid(this.right));
    }

    @Override
    public boolean hasChild() {
        return (this.getLe().hasChild() || this.right.hasChild());
    }
}