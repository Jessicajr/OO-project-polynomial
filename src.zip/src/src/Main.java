package src;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class Main {

    private static String getMyDiff(Combine knod,int nestSon) {
        knod.defineType();
        String strLeft;
        String strRight;
        String sam;
        boolean legalJudge = knod.legalNew();
        if (!legalJudge) {
            wrongPrint();
        }
        if (knod.getTy().equals("basic")) {
            legalJudge = legalJudge && knod.legal();
            if (!legalJudge) {
                wrongPrint();
            }
            return knod.getDiff("","");
        }
        if (knod.getTy().equals("Nest")) {
            Nest newKnod = new Nest(knod.getEx(),nestSon);
            newKnod.getChild();
            legalJudge = legalJudge && newKnod.legal();
            if (!legalJudge) {
                wrongPrint();
            }
            Combine kid = newKnod.getLe();
            strLeft = getMyDiff(kid,0);
            sam = newKnod.getDiff(strLeft,"");
            return sam;
        } else if (knod.getTy().equals("Add")) {
            Add newKnod1 = new Add(knod.getEx(),nestSon);
            newKnod1.getChild();
            legalJudge = legalJudge && newKnod1.legal();
            if (!legalJudge) {
                wrongPrint();
            }
            Combine kid1 = newKnod1.getLe();
            Combine kid2 = newKnod1.getRi();
            strLeft = getMyDiff(kid1,0);
            strRight = getMyDiff(kid2,0);
            sam = newKnod1.getDiff(strLeft,strRight);
            return sam;
        } else {
            Mul newKnod2 = new Mul(knod.getEx(),nestSon);
            newKnod2.getChild();
            legalJudge = legalJudge && newKnod2.legal();
            if (!legalJudge) {
                wrongPrint();
            }
            Combine kid1 = newKnod2.getLe();
            Combine kid2 = newKnod2.getRi();
            strLeft = getMyDiff(kid1,0);
            strRight = getMyDiff(kid2,0);
            sam = newKnod2.getDiff(strLeft,strRight);
            return sam;
        }
    }

    private static void wrongPrint() {
        System.out.print("WRONG FORMAT!");
        System.exit(0);
    }

    private static String turn(String line1) {
        String line = line1;
        Pattern wrong = Pattern.compile("[\\*\\^][+-]{2,}\\d+|[+-]{3,}[^\\d]|" +
                "\\*[+-][^\\d]|[+-]{4,}");
        Matcher matcher = wrong.matcher(line);
        if (matcher.find()) {
            wrongPrint();
        }
        line = line.replaceAll("\\+\\+","+");
        line = line.replaceAll("\\+\\-","-");
        line = line.replaceAll("\\-\\+","-");
        line = line.replaceAll("\\-\\-","+");
        line = line.replaceAll("\\+\\+","+");
        line = line.replaceAll("\\+\\-","-");
        line = line.replaceAll("\\-\\+","-");
        line = line.replaceAll("\\-\\-","+");
        Pattern replace = Pattern.compile("\\([\\+\\-]\\(");
        Matcher matchRe = replace.matcher(line);
        while (matchRe.find()) {
            line = line.replaceAll("\\(\\+\\(","(1*(");
            line = line.replaceAll("\\(\\-\\(","(-1*(");
            matchRe = replace.matcher(line);
        }
        line = line.replaceAll("^\\+\\(","1*(");
        line = line.replaceAll("^\\-\\(","-1*(");
        return line;
    }

    private static String init() {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        Pattern wrong = Pattern.compile("[+-]\\s*[+-]\\s*[+-]\\s+\\d+|" +
                "\\d+\\s+\\d+|\\d+\\s*(x|sin|cos)" +
                "|(x|sin(x)|cos(x))\\s*\\d+|[\\f\\n\\r\\v]+" +
                "|\\^\\s*[+-]\\s+\\d+|s\\s+i" +
                "|i\\s+n|c\\s+o|o\\s+s|\\*\\s*[+-]\\s+\\d+");
        if (line.length() == 0 || line.split("\\s*").length == 0) {
            wrongPrint();
        } Matcher wrongMatch = wrong.matcher(line);
        if (wrongMatch.find()) {
            wrongPrint();
        }
        Pattern wrongSym = Pattern.compile("[^xsincos\\(\\)\\^\\d\\+\\-\\*]");
        line = line.replaceAll("\\s*", "");
        Matcher wrong2 = wrongSym.matcher(line);
        if (wrong2.find()) {
            wrongPrint();
        }
        line = line.replaceAll("^\\+\\(","1*(");
        line = line.replaceAll("^\\-\\(","-1*(");
        return line;
    }

    public static void main(String[] args) {
        try {
            String line;
            line = init();
            line = turn(line);
            Combine knod = new Combine(line, 0);
            String line0 = getMyDiff(knod,0);
            /*Pattern change2 = Pattern.compile("(\\()(\\d+)(\\))");
            Matcher match2 = change2.matcher(line0);
            while (match2.find()) {
                String gr1 = match2.group(1);
                String gr3 = match2.group(3);
                String gr2 = match2.group(2);
                String line1 = String.format("\\%s%s\\%s",gr1,gr2,gr3);
                line0 = line0.replaceAll(line1,gr2);
                match2 = change2.matcher(line0);
            }*/
            Pattern change1 = Pattern.compile("([\\+\\-\\*\\^])(0+)(\\d+)");
            Matcher match1 = change1.matcher(line0);
            while (match1.find()) {
                String line1 = String.format("\\%s", match1.group(0));
                String group1 = match1.group(1);
                String line2 = String.format("\\%s",group1 + match1.group(3));
                line0  = line0.replaceAll(line1,line2);
                match1 = change1.matcher(line0);
            }
            line0 = line0.replaceAll("\\+\\+","+");
            line0 = line0.replaceAll("\\+\\-","-");
            line0 = line0.replaceAll("\\-\\+","-");
            line0 = line0.replaceAll("\\-\\-","+");
            System.out.print(line0);
        } catch (Exception e) {
            wrongPrint();
        }
    }

}
