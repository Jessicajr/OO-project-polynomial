package src;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Nest extends Combine implements CombineElement {
    private BigInteger coeff;
    private String nestType;

    public Nest(String str,int mark) {
        super(str,mark);
        String[] temp = this.getEx().split("\\^");
        if (temp.length < 2) {
            this.coeff = new BigInteger("1");
        } else {
            Pattern number = Pattern.compile("^[+-]?\\d+$");
            Matcher matchNumber = number.matcher(temp[temp.length - 1]);
            if (matchNumber.matches()) {
                this.coeff = new BigInteger(matchNumber.group());
                StringBuilder str1 = new StringBuilder();
                char[] str2 = this.getEx().toCharArray();
                int i;
                for (i = str2.length - 1;i >= 0;i--) {
                    if (str2[i] == '^') {
                        break;
                    }
                } for (int j = 0;j < i;j++) {
                    str1.append(str2[j]);
                }
                this.setEx(str1.toString());
            } else {
                this.coeff = new BigInteger("1");
            }
        }
        Pattern nestPattern = Pattern.compile("^([+-])?(sin|cos)");
        Matcher nestMatch = nestPattern.matcher(this.getEx());
        if (!nestMatch.find()) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        } else {
            if (nestMatch.group(1) == null) {
                if (nestMatch.group().contains("sin")) {
                    this.nestType = "sin";
                    return;
                }
                this.nestType = "cos";
            } else if (nestMatch.group(1).equals("+")) {
                if (nestMatch.group().contains("sin")) {
                    this.nestType = "sin";
                    return;
                }
                this.nestType = "cos";
            } else {
                if (nestMatch.group().contains("sin")) {
                    this.nestType = "-sin";
                    return;
                }
                this.nestType = "-cos";
            }
        }
    }

    @Override
    public void getChild() {
        String str = this.getEx().replaceFirst("^[+-]?sin\\(|^[+-]?cos\\(","");
        char[] temp = str.toCharArray();
        StringBuilder str1 = new StringBuilder();
        for (int i = 0;i < temp.length - 1;i++) {
            str1.append(temp[i]);
        }
        this.setLe(new Combine(str1.toString(),1));
    }

    @Override
    public String getDiff(String strLeft,String strRight) {
        Pattern zeroMatch = Pattern.compile("^0$|^\\(0\\)$");
        Matcher match1 = zeroMatch.matcher(strLeft);
        String str = new String();
        if (match1.matches()) {
            return "0";
        }
        str = "(" + strLeft + ")*";
        if (this.nestType.equals("sin")) {
            str += this.getEx().replaceFirst("^(\\+)?sin","cos");
        } else if (this.nestType.equals("cos")) {
            str += this.getEx().replaceFirst("^(\\+)?cos","-1*sin");
        } else if (this.nestType.equals("-sin")) {
            str += this.getEx().replaceFirst("^\\-sin","-1*cos");
        } else {
            str += this.getEx().replaceFirst("^\\-cos","sin");
        }
        if (this.coeff.compareTo(new BigInteger("1")) != 0) {
            str += "*" + this.coeff.toString() + "*" + this.getEx();
            str += "^" + this.coeff.add(new BigInteger("-1")).toString();
        }
        return str;
    }

    @Override
    public boolean legal() {
        boolean judge = true;
        if (this.coeff.compareTo(new BigInteger("10000")) > 0) {
            judge = false;
        }
        return (valid(this.getLe()) && judge);
    }

}