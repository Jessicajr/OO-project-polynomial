package src;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Add extends Combine implements CombineElement {
    private Combine right;
    private String addType;

    public Add(String str,int mark) {
        super(str,mark);
    }

    @Override
    public boolean legal() {
        return (valid(this.getLe()) && valid(this.right));
    }

    @Override
    public void getChild() {
        int flag = 0;
        int i;
        int j;
        int flag1 = 0;
        char[] rawOp = this.getEx().toCharArray();
        StringBuilder left = new StringBuilder();
        for (i = 0; i < rawOp.length; i++) {
            if (rawOp[i] != '+' && rawOp[i] != '-') {
                flag1++;
                left.append(rawOp[i]);
                if (rawOp[i] == '(') {
                    flag++;
                }
                if (rawOp[i] == ')') {
                    flag--;
                }
            } else if (flag1 == 0) {
                left.append(rawOp[i]);
            } else if (rawOp[i - 1] == '*' || rawOp[i - 1] == '^') {
                left.append(rawOp[i]);
            } else if (flag == 0) {
                this.setLe(new Combine(left.toString(),0));
                if (rawOp[i] == '+') {
                    this.addType = "+";
                } else {
                    this.addType = "-";
                }
                break;
            } else {
                left.append(rawOp[i]);
            }
        }
        StringBuilder right = new StringBuilder();
        for (j = i + 1; j < rawOp.length;j++) {
            right.append(rawOp[j]);
        }
        this.right = new Combine(right.toString(),0);
    }

    @Override
    public String getDiff(String strLeft,String strRight) {
        Pattern zeroMatch = Pattern.compile("^0$|^\\(0\\)$");
        Matcher match1 = zeroMatch.matcher(strLeft);
        Matcher match2 = zeroMatch.matcher(strRight);
        this.right.defineType();
        boolean judgeKid = this.right.getTy().equals("Add");
        if (match1.matches() && match2.matches()) {
            return "0";
        } else if (match2.matches()) {
            return strLeft;
        } else {
            if (this.addType.equals("+")) {
                return ("(" + strLeft + ")" + "+" + "(" + strRight + ")");
            } else if (!judgeKid) {
                return ("(" + strLeft + ")" + "-" + "(" + strRight + ")");
            } else if (this.right.getBr()) {
                return ("(" + strLeft + ")" + "-" + "(" + strRight + ")");
            }
            return ("(" + strLeft + ")" + "-" + strRight);
        }
    }

    @Override
    public boolean hasChild() {
        return (this.getLe().hasChild() || this.right.hasChild());
    }

    public Combine getRi() {
        return this.right;
    }
}