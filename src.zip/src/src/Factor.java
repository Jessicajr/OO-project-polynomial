package src;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Factor {                                            //最内层，解决系数*常数，幂函数，三角函数
    private BigInteger ex;
    private String facType;
    private int sym;

    public Factor(BigInteger ex,String str) {
        if (ex.compareTo(new BigInteger("10000")) > 0) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        }
        this.ex = ex;
        Pattern pat = Pattern.compile("[+-]");
        Matcher match = pat.matcher(str);
        if (!match.find()) {
            this.facType = str;
            this.sym = 1;
        } else if (match.group().equals("+")) {
            this.facType = str.replace("+","");
            this.sym = 1;
        } else {
            this.facType = str.replace("-","");
            this.sym = -1;
        }
    }

    public String toString() {
        String str = this.facType;
        if (this.ex.compareTo(new BigInteger("0")) == 0) {
            str = "1";
            return str;
        } else if (this.ex.compareTo(new BigInteger("1")) == 0) {
            return str;
        } else {
            str += "^" + this.ex.toString();
            return str;
        }

    }

    public String facDiff() {
        switch (this.facType) {
            case(""): return "0";
            case ("x"):
                if (this.ex.compareTo(new BigInteger("0")) == 0) {
                    return "0";
                } else if (this.ex.compareTo(new BigInteger("1")) == 0) {
                    if (this.sym == 1) {
                        return "1";
                    } return "-1";
                } BigInteger te = new BigInteger("1");
                Factor temp = new Factor(this.ex.subtract(te),this.facType);
                String str = new String();
                if (this.sym == -1) {
                    str += this.ex.negate().toString() + "*" + temp.toString();
                    return str;
                } str += this.ex.toString() + "*" + temp.toString();
                return str;
            case ("cos(x)"):
                temp = new Factor(new BigInteger("1"),"sin(x)");
                str = temp.toString();
                if (this.ex.compareTo(new BigInteger("1")) == 0) {
                    if (this.sym == -1) {
                        return str;
                    } str = "-1*" + str;
                    return str;
                } if (this.ex.compareTo(new BigInteger("0")) == 0) {
                    str = "0";
                    return str;
                } BigInteger tep = new BigInteger("1");
                Factor temp1 = new Factor(this.ex.subtract(tep),"cos(x)");
                if (this.sym == 1) {
                    str = this.ex.negate().toString() + "*" + str;
                    str += "*" + temp1.toString();
                    return str;
                } str += "*" + this.ex.toString() +  "*" + temp1.toString();
                return str;
            case ("sin(x)"):
                temp = new Factor(new BigInteger("1"),"cos(x)");
                str = temp.toString();
                if (this.ex.compareTo(new BigInteger("1")) == 0) {
                    if (this.sym == 1) {
                        return str;
                    } str = "-1*" + str;
                    return str;
                } if (this.ex.compareTo(new BigInteger("0")) == 0) {
                    str = "0";
                    return str;
                }   tep = new BigInteger("1");
                temp1 = new Factor(this.ex.subtract(tep),"sin(x)");
                if (this.sym == 1) {
                    str = this.ex.toString() + "*" + str;
                    str += "*" + temp1.toString();
                    return str;
                } str = this.ex.negate().toString() + "*" + str;
                str += "*" + temp1.toString();
                return str;
            default: return wrongPrint1();
        }
    }

    public String wrongPrint1() {
        System.out.print("WRONG FORMAT!");
        System.exit(0);
        return "";
    }

}
