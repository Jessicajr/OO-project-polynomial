package src;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.math.BigInteger;

public class Combine {
    private Combine left;
    private String express;
    private String combineType;
    private boolean brack = false;

    public boolean getBr() {
        return this.brack;
    }

    public String getEx() {
        return this.express;
    }

    public String getTy() {
        return this.combineType;
    }

    public void setLe(Combine b) {
        this.left = b;
    }

    public Combine getLe() {
        return this.left;
    }

    public void setEx(String str) {
        this.express = str;
    }

    public boolean valid(Combine cb) {
        if (cb == null) {
            return false;
        } else if (cb.express.length() == 0) {
            return false;
        }
        return true;
    }

    public Combine(String str,int mark) {
        if (str.length() == 0) {
            System.out.print("WRONG FORMAT!");
            System.exit(0);
        }
        Pattern isFactor = Pattern.compile("^[+-]?\\d+$|^[+-]?" +
                "(x|sin\\(x\\)|cos\\(x\\))(\\^[+-]?\\d+)?$");
        Matcher match = isFactor.matcher(str);
        if (match.matches() && mark == 0) {
            this.express = str;
        } else {
            Pattern isFactor1 = Pattern.compile("^[+-]?\\d+$|^(x|sin\\(x\\)" +
                    "|cos\\(x\\))(\\^[+-]?\\d+)?$");
            Matcher match1 = isFactor1.matcher(str);
            if (mark == 1 && match1.matches()) {
                this.express = str;
            } else {
                int flag = 0;
                String str2 = str.replaceAll("\\^[+-]?\\d+$","");
                char[] str1 = str2.toCharArray();
                for (int i = 0; i < str1.length; i++) {
                    boolean judge1 = ((flag == 0) && (mark == 1));
                    boolean judge2 = (str1[i] == '+' || str1[i] == '-');
                    boolean judge3 = str1[i] == '*';
                    if ((judge2 || judge3) && judge1) {
                        System.out.print("WRONG FORMAT!");
                        System.exit(0);
                    } else if (str1[i] == '(') {
                        flag++;
                    } else if (str1[i] == ')') {
                        if (flag > 0) {
                            flag--;
                        } else {
                            System.out.print("WRONG FORMAT!");
                            System.exit(0);
                        }
                    }
                }
                if (flag != 0) {
                    System.out.print("WRONG FORMAT!");
                    System.exit(0);
                }
                flag = 0;
                int i = canDel(str);
                str1 = str.toCharArray();
                if (i != 0) {
                    this.brack = true;
                    StringBuilder temp = new StringBuilder();
                    for (int j = i;j < str1.length - i;j++) {
                        temp.append(str1[j]);
                    }
                    this.express = temp.toString();
                } else {
                    this.express = str;
                }
            }
        }
    }

    public int canDel(String str2) {
        String str = str2;
        int count = 0;
        int i;
        char[] str1 = str.toCharArray();
        while (hasDel(str1)) {
            count++;
            StringBuilder temp = new StringBuilder();
            for (i = 1; i < str1.length - 1; i++) {
                temp.append(str1[i]);
            }
            str = temp.toString();
            str1 = str.toCharArray();
        }
        return count;
    }

    public boolean hasDel(char[] str1) {
        int flag = 0;
        int i;
        if (str1[0] == '(' && str1[str1.length - 1] == ')') {
            for (i = 1; i < str1.length; i++) {
                if (str1[i] == '(') {
                    flag++;
                } else if (str1[i] == ')') {
                    if (flag == 0) {
                        break;
                    } else {
                        flag--;
                    }
                }
            } if (i == str1.length - 1) {
                return true;
            }
        }
        return false;
    }

    public boolean legalNew() {
        Pattern exp = Pattern.compile("\\)\\^[+-]?\\d+$");
        Matcher matchExp = exp.matcher(this.express);
        if (matchExp.find()) {
            boolean ju1 = this.combineType.equals("Mul");
            boolean ju2 = this.combineType.equals("Add");
            if (ju1 || ju2) {
                String del = this.express.replaceAll("\\^[+-]?\\d+$","");
                char[] str1 = del.toCharArray();
                if (str1[0] == '(') {
                    int flag = 0;
                    int i;
                    for (i = 1;i < str1.length;i++) {
                        if (str1[i] == '(') {
                            flag++;
                        } else if (str1[i] == ')') {
                            if (flag == 0) {
                                break;
                            } else {
                                flag--;
                            }
                        }
                    } if (i == str1.length - 1) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public boolean legal() {
        if (this.combineType.equals("basic")) {
            return true;
        } else {
            if (!valid(this.left)) {
                return false;
            }
        }
        return false;
    }

    public void defineType() {
        Pattern isFactor = Pattern.compile("^[+-]?\\d+$|^[+-]?" +
                "(x|sin\\(x\\)|cos\\(x\\))(\\^[+-]?\\d+)?$");
        Matcher match = isFactor.matcher(this.express);
        if (match.matches()) {
            this.combineType = "basic";
        } else {
            Pattern nestPa = Pattern.compile("^[+-]?sin|^[+-]?cos");
            Matcher match1 = nestPa.matcher(this.express);
            String str2 = this.express.replaceFirst("\\^[+-]?\\d+$","");
            char[] str1 = str2.toCharArray();
            if (match1.find() && str1[str1.length - 1] == ')') {
                int flag = 0;
                int i;
                for (i = 3;i < str1.length;i++) {
                    if (str1[i] == '(') {
                        flag++;
                    } if (str1[i] == ')') {
                        flag--;
                        if (flag == 0) {
                            break;
                        }
                    } }
                if (i == str1.length - 1) {
                    this.combineType = "Nest";
                    return;
                }
            }
            int flag = 0;
            int j;
            for (j = 0;j < str1.length;j++) {
                if ((str1[j] == '+' || str1[j] == '-') && (flag == 0)) {
                    if (j == 0) {
                        continue;
                    } else if (str1[j - 1] == '*' || str1[j - 1] == '^') {
                        continue;
                    }
                    this.combineType = "Add";
                    return;
                } else if (str1[j] == '(') {
                    flag++;
                } else if (str1[j] == ')') {
                    flag--;
                }
            }
            this.combineType = "Mul";
        }
    }

    public String getDiff(String strLeft,String strRight) {
        Pattern isFactor = Pattern.compile("^[+-]?\\d+$|^[+-]?" +
                "(x|sin\\(x\\)|cos\\(x\\))(\\^[+-]?\\d+)?$");
        Matcher match = isFactor.matcher(this.express);
        if (match.matches()) {
            Pattern isCons = Pattern.compile("^[+-]?\\d+$");
            Pattern other = Pattern.compile("^([+-]?x|[+-]?" +
                    "sin\\(x\\)|[+-]?cos\\(x\\))(\\^[+-]?\\d+)?");
            Matcher matchCon = isCons.matcher(this.express);
            Matcher matchOther = other.matcher(this.express);
            if (matchCon.matches()) {
                Factor temp = new Factor(new BigInteger("0"),"");
                return temp.facDiff();
            } else if (matchOther.matches()) {
                if (matchOther.group(2) == null) {
                    BigInteger one = new BigInteger("1");
                    Factor temp = new Factor(one,matchOther.group(1));
                    return temp.facDiff();
                } else {
                    String[] str = matchOther.group().split("\\^");
                    Factor temp = new Factor(new BigInteger(str[1]),str[0]);
                    return temp.facDiff();
                }
            }
        }
        return "";
    }

    public boolean hasChild() {
        if (this.combineType.equals("basic")) {
            return false;
        } else {
            return (this.left.hasChild());
        }
    }
}





