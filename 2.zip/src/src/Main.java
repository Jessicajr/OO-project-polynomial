import poly.Check;
import poly.Poly;

public class Main {
    public static void main(String[] args) {

        try
        {
            //PolyTest tester = new PolyTest();
            //tester.test();
            Poly poly = new Poly(Check.getInput());
            //System.out.println(poly.toString());
            System.out.println(poly.getDerivative().toString());

        } catch (Exception e) {
            Check.wrongFormat();
        }

    }
}
