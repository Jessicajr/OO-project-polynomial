package poly;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Poly {
    private LinkedList<Term> poly;
    private static Pattern termPattern = Pattern.compile(
        "^[-+]{1,2}([-+]?\\d+|x(\\^[-+]?\\d+)?" +
            "|((sin\\(x\\)|cos\\(x\\))(\\^[-+]?\\d+)?))" +
            "(\\*([-+]?\\d+|x(\\^[-+]?\\d+)?" +
            "|((sin\\(x\\)|cos\\(x\\))(\\^[-+]?\\d+)?)))*");

    public Poly() {
        poly = new LinkedList<>();
    }

    public Poly(String line) {
        String ln = line;
        if (ln == null || ln.length() == 0) {
            Check.wrongFormat();
            return;
        }
        ln = Check.checkSpace(ln);
        poly = new LinkedList<>();
        ln = Check.addFirstSign(ln);
        while (ln != null & !ln.isEmpty()) {
            String termString = getFirstTermString(ln);
            if (termString == null) {
                Check.wrongFormat();
                poly.clear();
                return;
            }
            ln = ln.substring(termString.length()); //check
            Term term = new Term(termString);
            addTerm(term);
        }
    }

    private static String getFirstTermString(String ln) {
        Matcher m = termPattern.matcher(ln);
        if (m.find()) {
            return m.group(0);
        } else {
            return null;
        }
    }

    public void addTerm(Term term) {
        if (term.getCoef().equals(BigInteger.ZERO)) {
            return;
        }
        if (poly.size() == 0) {
            poly.add(term);
        } else {
            for (Term t : poly) {
                int flag = t.mergeFlag(term);
                if (flag == 0) {
                    t.add(term);
                    return;
                }
                else if (flag > 0) {
                    BigInteger a1 = t.getCoef();
                    BigInteger a2 = term.getCoef();
                    BigInteger x1 = t.getExpoX();
                    BigInteger x2 = term.getExpoX();
                    BigInteger s1 = t.getExpoSin();
                    BigInteger s2 = term.getExpoSin();
                    BigInteger c1 = t.getExpoCos();
                    BigInteger c2 = term.getExpoCos();
                    Term t1;
                    Term t2;
                    if (flag == 1) {
                        t1 = new Term(a1.subtract(a2), x1, s1, c1);
                        t2 = new Term(a2, x2,
                            s2.subtract(new BigInteger("2")), c2);

                    }
                    else {
                        t1 = new Term(a1.subtract(a2), x1, s1, c1);
                        t2 = new Term(a2, x2,
                            s2, c2.subtract(new BigInteger("2")));
                    }
                    if (t1.toString().length() + t2.toString().length()
                        <= term.toString().length() + t.toString().length()) {
                        poly.remove(t);
                        addTerm(t1);
                        addTerm(t2);
                        return;
                    }
                }
            }
            if (term.getSign()) {  // add the positive term in front of list
                poly.addFirst(term);
            } else {
                poly.addLast(term);
            }
        }
    }

    public String toString() {
        String s = "";
        Boolean firstTerm = true;
        if (poly == null || poly.size() == 0) {
            return "0";
        }

        for (Term t : poly) {

            BigInteger coef = t.getCoef();
            if (coef.equals(BigInteger.ZERO)) {
                continue;
            }
            if (firstTerm) {
                s += t.toString();
                firstTerm = false;
            } else {
                if (coef.compareTo(BigInteger.ZERO) > 0) {
                    s += "+" + t.toString();
                } else {
                    s += t.toString();
                }
            }
        }

        if (s == "") {
            return "0";
        } else {
            return s;
        }
    }

    public Poly getDerivative() {
        Poly derivative = new Poly();

        for (Term t : poly) {
            BigInteger coef = t.getCoef();
            BigInteger expoX = t.getExpoX();
            BigInteger expoSin = t.getExpoSin();
            BigInteger expoCos = t.getExpoCos();
            Term t1 = new Term(coef.multiply(expoX),
                expoX.subtract(BigInteger.ONE), expoSin, expoCos);
            Term t2 = new Term(coef.multiply(expoSin), expoX,
                expoSin.subtract(BigInteger.ONE), expoCos.add(BigInteger.ONE));
            Term t3 = new Term(BigInteger.ZERO.subtract(coef.multiply(expoCos)),
                expoX, expoSin.add(BigInteger.ONE),
                expoCos.subtract(BigInteger.ONE));
            derivative.addTerm(t1);
            derivative.addTerm(t2);
            derivative.addTerm(t3);
        }

        return derivative;
    }
}




















