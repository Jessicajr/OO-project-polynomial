package poly;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Term implements Comparable<Term> {
    private BigInteger coef;
    private BigInteger expoX;
    private BigInteger expoSin;
    private BigInteger expoCos;
    private Boolean sign;
    private static Pattern[] factor;

    static
    {
        factor = new Pattern[3];
        factor[0] = Pattern.compile("[-+]?\\d+");
        factor[1] = Pattern.compile("x(\\^[-+]?\\d+)?");
        factor[2] = Pattern.compile("(sin\\(x\\)|cos\\(x\\))(\\^[-+]?\\d+)?");
    }

    public Term(BigInteger co,BigInteger xe,BigInteger se,BigInteger ce)
    {
        if (co == null || xe == null || se == null || ce == null)
        {
            Check.wrongFormat();
        } else {
            this.coef  = new BigInteger(co.toString());
            this.expoX   = new BigInteger(xe.toString());
            this.expoSin = new BigInteger(se.toString());
            this.expoCos = new BigInteger(ce.toString());
            this.sign = co.compareTo(BigInteger.ZERO) > 0;
        }
    }

    public Term(String termStr)
    {
        coef  = BigInteger.ONE;
        expoX   = BigInteger.ZERO;
        expoSin = BigInteger.ZERO;
        expoCos = BigInteger.ZERO;
        sign = true;
        String termString = simplify(termStr);
        String[] facts = termString.split("\\*");
        for (String s : facts)
        {
            Matcher m = factor[0].matcher(s);
            if (m.matches())  //"[-+]\\d+"
            {
                mulFact(m.group(0),0);
            } else {
                m = factor[1].matcher(s);
                if (m.matches())  //"x(\\^[-+]\\d)*"
                {
                    mulFact(m.group(0),1);
                } else {
                    m = factor[2].matcher(s);
                    if (m.matches()) //"(sin\\(x\\)|cos\\(x\\))(\\^[-+]\\d)*"
                    {
                        mulFact(m.group(0),2);
                    } else {
                        Check.wrongFormat();
                    }
                }
            }
        }
        if (!sign)
        {
            coef = BigInteger.ZERO.subtract(coef);
        }
        //System.out.println("Coef :" + coef + " expoX :" + expoX
        //    + " expoSin :" + expoSin + " expoCos " + expoCos);
    }

    public BigInteger getCoef() { return coef; }

    public BigInteger getExpoX() { return expoX; }

    public BigInteger getExpoCos() { return expoCos; }

    public BigInteger getExpoSin() { return expoSin; }

    public Boolean getSign() { return sign; }

    private void mulFact(String factStr,int type)
    {
        switch (type) {
            case 0: //a
                coef = coef.multiply(new BigInteger(factStr));
                break;
            case 1: //"x(\\^[-+]\\d)*"
                if (factStr.equals("x"))
                {
                    expoX = expoX.add(BigInteger.ONE);
                } else {
                    expoX = expoX.add(new BigInteger(factStr.substring(2)));
                }
                break;
            case 2:
                if (factStr.substring(0,6).equals("sin(x)"))
                {
                    if (factStr.length() == 6)
                    {
                        expoSin = expoSin.add(BigInteger.ONE);
                    } else {
                        expoSin = expoSin.add(
                            new BigInteger(factStr.substring(7)));
                    }
                } else {
                    if (factStr.equals("cos(x)"))
                    {
                        expoCos = expoCos.add(BigInteger.ONE);
                    } else {
                        expoCos = expoCos.add(
                            new BigInteger(factStr.substring(7)));
                    }
                }
                break;
            default:
                Check.wrongFormat();
                break;

        }
    }

    private String simplify(String termString)
    {
        String str = termString;
        if (str.charAt(0) == '-') {
            sign = !sign;
        }
        if (str.charAt(1) == '+') {
            str = str.substring(2);
        }
        else if (str.charAt(1) == '-') {
            str = str.substring(2);
            sign = !sign;
        } else {
            str = str.substring(1);
        }
        return str;
    }

    public String toString()
    {
        String s = "";
        if (coef.equals(BigInteger.ZERO)) {
            return s;
        }
        else {
            Boolean firstFact = true;
            if (!expoX.equals(BigInteger.ZERO)) {
                s += "x";
                firstFact = false;
                if (!expoX.equals(BigInteger.ONE)) {
                    s += "^" + expoX.toString();
                }
            }
            if (!expoSin.equals(BigInteger.ZERO)) {
                if (firstFact) {
                    s += "sin(x)";
                    firstFact = false;
                } else {
                    s += "*sin(x)";
                }
                if (!expoSin.equals(BigInteger.ONE)) {
                    s += "^" + expoSin.toString();
                }
            }
            if (!expoCos.equals(BigInteger.ZERO)) {
                if (firstFact) {
                    s += "cos(x)";
                    firstFact = false;
                } else {
                    s += "*cos(x)";
                }
                if (!expoCos.equals(BigInteger.ONE))
                {
                    s += "^" + expoCos.toString();
                }
            }
            if (firstFact) {
                s = coef.toString();
            }
            else {
                if (coef.equals(new BigInteger("-1"))) {
                    s = "-" + s;
                }
                else if (!coef.equals(BigInteger.ONE)) {
                    s = coef.toString() + "*" + s;
                }
            }
        }
        return s;
    }

    public void add(Term o) {
        if (expoX.equals(o.getExpoX()) & expoSin.equals(o.getExpoSin())
            & expoCos.equals(o.getExpoCos())) {
            coef = coef.add(o.getCoef());
        }
    }

    public int compareTo(Term other) {
        return 0 - coef.compareTo(other.getCoef());
    }

    public int mergeFlag(Term o) {
        if (!expoX.equals(o.getExpoX())) { //cant not merge these shit
            return -1;
        }
        if (expoSin.equals(o.getExpoSin()) & expoCos.equals(o.getExpoCos())) {
            return 0;                      //merge the coefficient
        }
        else {
            BigInteger m = o.getExpoSin().subtract(this.expoSin);
            BigInteger n = o.getExpoCos().subtract(this.expoCos);
            if (m.equals(new BigInteger("2"))
                & n.equals(new BigInteger("-2"))) {
                // this = a * x^n * sin(x)^p * cos(x)^(q+2)
                // o    = b * x^n * sin(x)^p+2 *cos(x)^q
                return 1;
            }
            else if (m.equals(new BigInteger("-2"))
                & n.equals(new BigInteger("2"))) {
                // this = a * x^n * sin(x)^p+2 * cos(x)^q
                // o    = b * x^n * sin(x)^p   * cos(x)^q+2
                return 2;
            }
            else {
                return -1;
            }
        }
    }

}
