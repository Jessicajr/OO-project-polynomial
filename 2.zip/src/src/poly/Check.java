package poly;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Check {

    public static void wrongFormat() {
        System.out.println("WRONG FORMAT!");
        System.exit(0);
    }

    public static String getInput() {
        Scanner keyboard = new Scanner(System.in);
        if (!keyboard.hasNext()) {
            wrongFormat();
        }
        String ln = keyboard.nextLine();
        Pattern illegal = Pattern.compile("[^0-9*()cinos\\-+^x \\t]");
        if (ln == null || ln.isEmpty() || illegal.matcher(ln).find()) {
            wrongFormat();
        }
        return checkSpace(ln);
    }

    public static String checkSpace(String string) {
        String str = string;
        Pattern illegal1 = Pattern.compile("\\d\\s+\\d");
        Matcher m1 = illegal1.matcher(str);
        Pattern illegal2 = Pattern.compile("[-+]\\s*[-+]\\s*[-+]\\s+\\d");
        Matcher m2 = illegal2.matcher(str);
        Pattern illegal3 = Pattern.compile("[*^]\\s*[-+]\\s+\\d");
        Matcher m3 = illegal3.matcher(str);
        Pattern illegal4 = Pattern.compile("(s\\s+in|si\\s+n|c\\s+os|co\\s+s)");
        Matcher m4 = illegal4.matcher(str);
        if (m1.find() || m2.find() || m3.find() || m4.find()) {
            wrongFormat();
        }

        str = str.replace(" ", "");
        return str.replace("\t", "");
    }

    public static String addFirstSign(String str) {
        if (str.length() == 0) {
            Check.wrongFormat();
            return null;
        }
        if (str.charAt(0) != '+' && str.charAt(0) != '-') {
            return "+" + str;
        } else {
            return str;
        }

    }
}