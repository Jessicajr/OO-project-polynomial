import poly.Poly;

import java.io.FileInputStream;
import java.util.Scanner;

public class PolyTest {
    public void test()
    {
        Scanner inputStream = null;
        try
        {
            inputStream = new Scanner(
                new FileInputStream("test2.txt"));
            //inputStream = new Scanner(new FileInputStream("test.txt"));
        } catch (Exception e)
        {
            System.out.println(e.getStackTrace());
        }
        while (inputStream.hasNext())
        {
            try
            {
                String ln = inputStream.nextLine();
                System.out.println("Case:" + ln);
                Poly poly = new Poly(ln);
                System.out.println("Poly:" + poly.toString());
                Poly derivative = poly.getDerivative();
                System.out.println("Derivative:" + derivative.toString());
                System.out.println("----------------------------------------");
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
}

